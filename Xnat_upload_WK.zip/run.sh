#!/bin/bash
#SBATCH --ntasks=1           ### How many CPU cores do you need?
#SBATCH --mem=30G            ### How much RAM memory do you need?
#SBATCH -p long           ### The queue to submit to: express, short, long, interactive
#SBATCH --gres=gpu:1         ### How many GPUs do you need?
#SBATCH -t 1-00:00:00        ### The time limit in D-hh:mm:ss format
#SBATCH -o out_%j.log        ### Where to store the console output (%j is the job number)
#SBATCH -e error_%j.log      ### Where to store the error output
#SBATCH --job-name=Xnat_upload  ### Name your job so you can distinguish between jobs


# Load the modules

module purge
# automatically loads all dependencies such as cuda
module load Python/3.7.4-GCCcore-8.3.0
module load CUDA/11.1.1-GCC-10.2.0  
module load cuDNN/8.0.4.30-CUDA-11.1.1

# use when you need to read/write many files quickly in tmp directory:
# source /tmp/${SLURM_JOB_USER}.${SLURM_JOB_ID}/prolog.env

# activate virtualenv after loading tensorflow/python module
# replace with your own virtualenv!
source 
echo "start"

#python extract_information.py
#python Xnat_upload_general.py --host 'https://bigr-rad-xnat.erasmusmc.nl/' --user '   '  --password '   ' --project '   '

















