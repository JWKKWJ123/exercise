import xnat
import argparse
import os
import datetime
import glob
import pandas as pd
from pathlib import Path
import time
import zipfile
import pydicom



'''
There are several ways to get the information of scans, a more general way is to read from DICOM head file
By defaultThe ScanPath, ScanLabel and ScanFormat already exists in the csv/excel file, they can be specific in different dataset, so there is no universal way to generate this information. 
Other information can be obtained from DICOM headfile

'''



if __name__ == '__main__':
        
        base_dir = ('    ') #Parent folder of raw data. In the default structure, the scans is each subject is in a separate folder
        data_label = pd.read_excel("/overview of scans.xlsx")
        upload_list = []
        for i in range(len(data_label['ScanPath'])):
            scan_dir = data_label['ScanPath'][i]
            scan_dir =  base_dir + '/' scan_dir
            for f in os.listdir(scan_dir):
                         file_dir = scan_dir + f
                         if os.path.isdir(file_dir):
                            continue
                         
                         scan_info = []
                         ds = pydicom.dcmread(file_dir)
                         print(ds)
                         
                         subject_id = str(ds.get(0x00100010).value)  # subject ID, Tag: (0010,0010)
                         print(subject_id)
                         scan_id = str(ds.get(0x00200011).value)   # scan series number, Tag: (0020,0011)
                         print(scan_id)
                         scan_discription = ds.get(0x0008103E)[:]   # scan_discription, Tag: (0008,103E)
                         scan_date = ds.get(0x00080020)[:]   # scan_discription, Tag: (0008,0020)
                         
                         data_label['PTID'][i] = subject_id
                         data_label['ScanSeries'][i] = scan_id
                         data_label['ScanDiscription'][i] = scan_discription
                         data_label['ScanDate'][i] = scan_date
                         if scan_id != None:
                            break
                         
        data_label.to_excel('/overview of scans.xlsx')
        
        
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         
                         