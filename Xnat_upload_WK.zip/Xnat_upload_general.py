#!/usr/bin/env python
import xnat
import argparse
import os
import datetime
import glob
import pandas as pd
from pathlib import Path
import time
import zipfile



def upload_scan_dicom(session, project, subject, scan_type, scan_path, scan_label, scan_id, scan_date,scan_description,scan_notes):
    """ 
    Upload scan to XNAT.

    Input:
    - session: XNAT session
    - project: string of XNAT project ID
    - subject: string of XNAT subject ID
    - scan_type: string indicating scan type (e.g. T1 or FLAIR)
    - scan_path path to scan on local computer
    - scan_label: string of label, e.g. 001_S_0001_bl, can also be called experiment label, the scans in the same experiment have the same label
    - scan_id: string of scan id that is provided during XNAT upload
    - scan_date: The time the scan was created
    - scan_description: string of description of the scan, exract from DICOM head file
    - scan_notes: string of notes relate to the scan, it can be anything

    Output:
    - result: string describing whether the upload was succesful or not
    """

    # Define project
    xnat_project = session.projects[project]


    # Find existing subject if a matching subject ID is found
    try:
        xnat_subject = xnat_project.subjects[subject]
        existing_subject = True

    # If subject does not yet exist in xnat, create new subject
    except KeyError:
        xnat_subject = session.classes.SubjectData(parent=xnat_project, label=subject)
        existing_subject = False


    # If subject already existed in XNAT
    if existing_subject:
        print('scan:',scan_path)

        # Initialization
        viscode_match = False

        # Loop over existing experiments
        for experiment in xnat_subject.experiments:
            xnat_experiment = xnat_subject.experiments[experiment]

            # If scan visit matches the visit of an existing experiment
            if xnat_experiment.label == scan_label:
                #print('exp_label:',exp_label)
                viscode_match = True
                scan_already_exists = False

                # Check whether scan of the correct scantype already exists within matching experiment
                for key, xnat_scan in xnat_experiment.scans.items():
                    print('xnat_scan.items:',key, xnat_scan.type)
                    if xnat_scan.id == scan_id:
                        scan_already_exists = True
                        result = 'Not uploaded, scanid already exists'
                        break 
						   ## Break loop if an existing scan of the correct scan type is already present in XNAT
     
                # If no scan with the correct scantype already exists, upload scan to existing experiment
                if not scan_already_exists:
                    xnat_scan = session.classes.MrScanData(parent=xnat_experiment, type=scan_type,id=scan_id, series_description= scan_description, note = scan_notes) 
                    image_file = session.classes.ResourceCatalog(parent=xnat_scan, label='DICOM')
                    try:
                     image_file.upload_dir(scan_path, os.path.basename(scan_path),method = 'tgz_file')
                    except:
                     print('failed to upload'+scan_id + ':' + scan_type)
                     break

                    if xnat_experiment.date == scan_date:        # If the scan date matches the date of the experiment
                        result = 'Uploaded to existing experiment of existing subject, experiment date and scan date match'
                    else:                                       # If the scan date does not match the date of the experiment
                        result = 'Uploaded to existing experiment of existing subject, experiment date and scan date do not match'

                break   # Break loop once the scan is uploaded or if a scan already exists

        # If no scan visit matches the visit of an existing experiment, create new experiment and upload scan
        if not viscode_match:
            new_experiment = session.classes.MrSessionData(parent=xnat_subject, label=scan_label, date=scan_date)
            xnat_scan = session.classes.MrScanData(parent=new_experiment, type=scan_type,id=scan_id, series_description= scan_description,note = scan_notes)
            image_file = session.classes.ResourceCatalog(parent=xnat_scan, label= 'DICOM')
            image_file.upload_dir(scan_path, os.path.basename(scan_path),method = 'tgz_file')
            result = 'Uploaded, new experiment of existing subject was created'

    # If a new subject was created, create new experiment and upload scan
    if not existing_subject:
        new_experiment = session.classes.MrSessionData(parent=xnat_subject, label=scan_label, date=scan_date)
        xnat_scan = session.classes.MrScanData(parent=new_experiment, type=scan_type,id=scan_id, series_description= scan_description,note = scan_notes)
        image_file = session.classes.ResourceCatalog(parent=xnat_scan, label='DICOM')
        image_file.upload_dir(scan_path, os.path.basename(scan_path),method = 'tgz_file')
        result = 'Uploaded, new subject and experiment were created'

    return result



def upload_scan_nifti(session, project, subject, scan_type, scan_path, scan_label, scan_id, scan_date,scan_description,scan_notes):
    """
    Upload scan to XNAT.

    Input:
    - session: XNAT session
    - project: string of XNAT project ID
    - subject: string of XNAT subject ID
    - scan_type: string indicating scan type (e.g. T1 or FLAIR)
    - scan_path path to scan on local computer
    - scan_label: string of label, e.g. 001_S_0001_bl, can also be called experiment label, the scans in the same experiment have the same label
    - scan_id: string of scan id that is provided during XNAT upload
    - scan_date: The time the scan was created
    - scan_description: string of description of the scan, exract from DICOM head file
    - scan_notes: string of notes relate to the scan, it can be anything

    Output:
    - result: string describing whether the upload was succesful or not
    """

    # Define project
    xnat_project = session.projects[project]


    # Find existing subject if a matching subject ID is found
    try:
        xnat_subject = xnat_project.subjects[subject]
        existing_subject = True

    # If subject does not yet exist in xnat, create new subject
    except KeyError:
        xnat_subject = session.classes.SubjectData(parent=xnat_project, label=subject)
        existing_subject = False

    # Extract scan date


    # If subject already existed in XNAT
    if existing_subject:
        #print('scan:',scan)

        # Initialization
        viscode_match = False

        # Loop over existing experiments
        for experiment in xnat_subject.experiments:
            #print('experiment:',experiment)
            xnat_experiment = xnat_subject.experiments[experiment]

            # If scan visit matches the visit of an existing experiment
            if xnat_experiment.label == scan_label:
                #print('exp_label:',exp_label)
                viscode_match = True
                scan_already_exists = False

                # Check whether scan of the correct scantype already exists within matching experiment
                
                for key, xnat_scan in xnat_experiment.scans.items():
                    for resource_idx, resource_label in enumerate(xnat_experiment.scans): 
                         if  xnat_scan.id == scan_id:
                            scan_already_exists = True
                            result = 'Not uploaded, scanid already exists'
                            break
                        #break   # Break loop if an existing scan of the correct scan type is already present in XNAT
                

                # If no scan with the correct scantype already exists, upload scan to existing experiment
                if not scan_already_exists:
                    
                    xnat_scan = session.classes.MrScanData(parent=xnat_experiment, type=scan_type, id= 'PAR/REC/nii')
                    image_file = session.classes.ResourceCatalog(parent=xnat_scan, label='NIFTI')
                    for scan_nifti in os.listdir(scan): 
                         scan_dir = Path(scan)
                         image_file.upload(scan_nifti, os.path.basename(scan_nifti))

                    if xnat_experiment.date == scan_date:        # If the scan date matches the date of the experiment
                        result = 'Uploaded to existing experiment of existing subject, experiment date and scan date match'
                    else:                                       # If the scan date does not match the date of the experiment
                        result = 'Uploaded to existing experiment of existing subject, experiment date and scan date do not match'

                break   # Break loop once the scan is uploaded or if a scan already exists

        # If no scan visit matches the visit of an existing experiment, create new experiment and upload scan
        if not viscode_match:
            new_experiment = session.classes.MrSessionData(parent=xnat_experiment, type=scan_type,id=scan_id, series_description= scan_description,note = scan_notes)
            xnat_scan = session.classes.MrScanData(parent=new_experiment, type=scantype, id= 'PAR/REC/nii')
            image_file = session.classes.ResourceCatalog(parent=xnat_scan, label='NIFTI')
            for scan_nifti in os.listdir(scan): 
                         scan_dir = Path(scan)
                         image_file.upload(scan_nifti, os.path.basename(scan_nifti))
            result = 'Uploaded, new experiment of existing subject was created'

    # If a new subject was created, create new experiment and upload scan
    if not existing_subject:
        new_experiment = session.classes.MrSessionData(parent=xnat_subject, label=exp_label, date=scan_date)
        xnat_scan = session.classes.MrScanData(parent=new_experiment, type= scan_type, id= 'PAR/REC/nii')
        image_file = session.classes.ResourceCatalog(parent=xnat_scan, label='NIFTI')
        for scan_nifti in os.listdir(scan): 
                         scan_dir = Path(scan)
                         image_file.upload(scan_nifti, os.path.basename(scan_nifti))
        result = 'Uploaded, new subject and experiment were created'

    return result






if __name__ == '__main__':
 #Pass in parameters
 start = time.perf_counter()
 base_dir = (' ') #Parent folder of raw data
 data_label = pd.read_excel("/overview of scans.xlsx") #File contains the information of each scan, including the scan path


 parser = argparse.ArgumentParser()
 parser.add_argument('--host', type=str, required=True, help='xnat host')
 parser.add_argument('--user', type=str, required=True, help='user name')
 parser.add_argument('--password', type=str, required=True, help='password')
 parser.add_argument('--project', type=str, required=True, help='Project id')
 args = parser.parse_args()
 host = args.host
 user = args.user
 password = args.password
 project = args.project

 err_num = 0
 result_tot = dict()
 upload_list = []


 with xnat.connect(host,user,password) as xnat_host:
        upload_scan = []
        xnat_project = xnat_host.projects[project]
        print('xnat_project:',xnat_project)
        '''
        get information from csv file:
        There is a seperate pyfile about the extraction of information from DICOM headfiles

        '''
        for i in range(len(data_label['PTID'])):
          subject = data_label['PTID'][i]
          print(data_label['ScanPath'][i])
          scan_path = base_dir + '/' + data_label['ScanPath'][i]
          scan_id = data_label['ScanSeries'][i]
          scan_type= data_label['ScanType'][i]
          scan_label = subject + '_' + data_label['ScanLabel'][i]
          scan_date = data_label['ScanDate'][i]
          scan_description = data_label['Scandescription'][i]
          scan_notes = data_label['Annotate'][i]
          
          data_format = data_label['ScanFormat'][i]
                    
          if data_format == 'DICOM':
                       try:
                        result = upload_scan_dicom(session = xnat_host,
                                     project = project, 
                                     subject = subject,
                                     scan_type = scan_type, 
                                     scan_path = scan_path,
                                     scan_label = scan_label,
                                     scan_id = scan_id,
                                     scan_date = scan_date,
                                     scan_description = scan_description,
                                     scan_notes = scan_notes)
                        print(result)
                        upload_scan.append(subject)
                        upload_scan.append(scantype)
                        upload_scan.append(result)
                        
                       
                       except Exception as e:
                        print(f'Encountered the following error: {e}')
                        err_num += 1
                        result = 'Not uploaded, encountered error during upload'
                        print(result)
                        upload_scan.append(subject)
                        upload_scan.append(scan_type)
                        upload_scan.append(result)
                        upload_scan.append(e)
                    
                                     
          #upload nifti data in one file
          if data_format == 'nii' or data_format == 'PAR' or data_format == 'REC':
                       scan_type = 'NIFTI_raw'
                       try:
                        result = upload_scan_nifti(session = xnat_host,
                                     project = project, 
                                     subject = subject,
                                     scan_type = scan_type, 
                                     scan_path = scan_path,
                                     scan_label = scan_label,
                                     scan_id = scan_id,
                                     scan_date = scan_date,
                                     scan_description = scan_description,
                                     scan_notes = scan_notes)
                        print(result)
                        upload_scan.append(subject)
                        upload_scan.append('NIFTI')
                        upload_scan.append(result)
                        
                       except Exception as e:
                          print(f'Encountered the following error: {e}')
                          err_num += 1
                          result = 'Not uploaded, encountered error during upload'
                          print(result)
                          upload_scan.append(subject)
                          upload_scan.append('NIFTI')
                          upload_scan.append(result)
                          upload_scan.append(e)
                          
          upload_list.append(upload_scan)
        
 upload_list = pd.DataFrame(upload_list,columns=['Subject ID', 'Scan name', 'Annotation' , 'error'])
 upload_list.to_csv('/report.csv',index=False)
 end = time.perf_counter()
 time_consume=end-start
 print(f'Encountered error during upload for {err_num} scans')
 print('total time consumeption:',time_consume)




